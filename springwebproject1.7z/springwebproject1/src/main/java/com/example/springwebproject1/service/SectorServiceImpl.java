package com.example.springwebproject1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springwebproject1.dao.SectorDao;
import com.example.springwebproject1.model.Sector;

@Service
public class SectorServiceImpl implements SectorService {
	
	@Autowired
	SectorDao sectordao;
	

	@Override
	public List<Sector> getSectorList() {
		// TODO Auto-generated method stub
		return sectordao.findAll();
		
	}

}
