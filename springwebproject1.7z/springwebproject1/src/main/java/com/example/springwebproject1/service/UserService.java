package com.example.springwebproject1.service;

import java.sql.SQLException;
import java.util.List;

import com.example.springwebproject1.model.User;

public interface UserService {
	
	public User registerUser(User user) throws SQLException;
    public List<User> findByUsername(String username);



}
